<?php
/**
 * Plugin Name: Simple Discount Plugin
 * Description: Applies discount on each product by a certain percentage
 * Version: 1.0
 * Author: Rajesh Bethu
 * Author URI: https://github.com/rajeshbethu
 */


if(!defined('ABSPATH')){
	die("You don't have access to this page.");
}

function create_discount_db() {
	global $wpdb;
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	$table_name = $wpdb->prefix . 'simplediscount';
	$sql = "CREATE TABLE $table_name ( id int(1), discount INT(3) )";
    dbDelta($sql);
	$wpdb->insert($table_name, array("id" => 1, "discount" => 0), array("%d", "%d"));
}

register_activation_hook( __FILE__, 'create_discount_db' );

function drop_discount_db(){
    global $wpdb;
    $table_name = $wpdb->prefix . 'simplediscount';
    $sql = "DROP TABLE $table_name";
    $wpdb->query($sql);
}

register_deactivation_hook( __FILE__, 'drop_discount_db' );


add_filter( 'woocommerce_get_price_html', 'display_discount', 9999, 2 );
 
function display_discount( $price_html, $product ) {
    global $wpdb;
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    $table_name = $wpdb->prefix . 'simplediscount';
    $result = $wpdb->get_results( "SELECT discount FROM $table_name WHERE id = 1" );
    foreach ($result as $key => $value) {
    	$discount_val = $value->discount;
    }
    if ($discount_val == 0) {
        return $price_html;
    }
    $orig_price = wc_get_price_to_display( $product );
    $discount = (100-$discount_val)/100;
    $price_html = wc_price( $orig_price * $discount );
    return $price_html." <del>$orig_price</del> <span style='color:green'>$discount_val% off</span>";
}

add_action( 'woocommerce_before_calculate_totals', 'apply_discount', 9999 );
 
function apply_discount( $cart ) {
	global $wpdb;
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    $table_name = $wpdb->prefix . 'simplediscount';
    $result = $wpdb->get_results( "SELECT discount FROM $table_name WHERE id = 1" );
    foreach ($result as $key => $value) {
    	$discount_val = $value->discount;
    }
    if ($discount_val == 0) {
        return;
    }
    foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
        $product = $cart_item['data'];
        $price = $product->get_price();
        $discount = (100-$discount_val)/100;
        $cart_item['data']->set_price( $price * $discount );
    }
}

add_action('admin_menu','create_settings_menu');

function create_settings_menu(){
	add_menu_page('My Discount Title','Discount Settings','manage_options','simple-discount-settings','show_discount_settings','dashicons-tag');
}
function show_discount_settings(){

	echo "<div class = 'wrap'><h2>Please enter discount percentage...</h2>
        <form action='?page=simple-discount-settings' method='post'>
            <input type='number' name='discount_value' placeholder='Enter discount in %...' style='width:40%'></div>
        	<div class='wrap'><input type='submit' name='discount_submit' class='' value='Apply' style='color:#2271b1;border:1px solid #2271b1;border-radius: 4px;'>
        </form>
    </div>";
    if(isset($_POST['discount_submit'])){
        $discount = $_POST["discount_value"];
        if (isset($discount) && !empty($discount)) {
            if ($discount >= 1) {
                global $wpdb;
                require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
                $table_name = $wpdb->prefix . 'simplediscount';
                $result = $wpdb->update($table_name, array("discount" => $discount), array('id' => 1));
                if ($result !== false) {
                    echo "<div class='wrap'><p style='color:green'>$discount% Discount applied successfully</p></div>";
                }
            }else{
                echo "<div class='wrap'><p style='color:red'>$discount% Negative discount cannot be applied. Please enter any positive number</p></div>";
            }
        }elseif (empty($discount)) {
            echo "<div class='wrap'><p style='color:red'>Please enter any number greater than zero...</p></div>";
        }
    }
}

add_filter( 'plugin_action_links_simple-discount/simple-discount.php', 'create_settings_link' );

function create_settings_link( $links ) {
    $url = esc_url( add_query_arg('page','simple-discount-settings', get_admin_url() . 'admin.php'));
    $settings_link = "<a href='$url'>Settings</a>";
    array_unshift($links, $settings_link);
    return $links;
}